
joye_scheme
=========================================
.. automodule:: joye_scheme
    :show-inheritance:
    :members:
    :undoc-members:
