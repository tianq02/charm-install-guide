
encap_bchk05
=========================================
.. automodule:: encap_bchk05
    :show-inheritance:
    :members:
    :undoc-members:
