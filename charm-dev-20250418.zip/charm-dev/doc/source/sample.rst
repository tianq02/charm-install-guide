Sample File of reStructuredText
========================================

Latex Equations
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
.. math::
   W^{3\beta}_{\delta_1 \rho_1 \sigma_2} \approx U^{3\beta}_{\delta_1 \rho_1}

Text Formatting
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Some text, *italic text*, **bold text**

* bulleted list.  There needs to be a space right after the "*"
* item 2

.. note::
    This is a note.
 
Here's some Python code:

>>> for i in range(10):
...     print i

